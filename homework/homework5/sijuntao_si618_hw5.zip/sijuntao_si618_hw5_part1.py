
import mrjob
import nltk
import re
from mrjob.job import MRJob
from nltk.stem.porter import *

pattern = r'\b[A-Za-z]{4,}\b'
stemmer = PorterStemmer()

class MRMostUsedWordStems(MRJob):
    OUTPUT_PROTOCOL = mrjob.protocol.TextProtocol

    def mapper(self, _, line):
        try:
            congress = line.split('\t')[4]  # congress
            if line != '' and line is not None:
                origin_word_list = re.findall(pattern, line)
                for origin_word in origin_word_list:
                    stem_word = stemmer.stem(origin_word)
                    yield (congress, stem_word), 1
        except:
            pass
       
    def combiner(self, word_stem, counts):
        # sums up the count for each (congress, stem) pair
        yield word_stem, sum(counts)

    def reducer(self, word_stem, counts):
        # gets the final list of counts for each (congress, word_stem)
        yield  word_stem[0] + "\t" + word_stem[1], str(sum(counts))
        

if __name__ == "__main__":
    MRMostUsedWordStems.run()
